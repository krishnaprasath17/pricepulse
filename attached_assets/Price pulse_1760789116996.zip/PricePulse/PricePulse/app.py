from flask import Flask, render_template, request, jsonify, session
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from datetime import datetime
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

def create_app():
    """Application factory pattern"""
    app = Flask(__name__)
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'your-secret-key-here')
    app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'mysql+pymysql://root:password@localhost/pricepulse')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    # Import db from models and initialize
    from models import db
    db.init_app(app)
    CORS(app)
    
    # Import routes after db initialization
    from routes import register_routes
    
    # Register routes
    register_routes(app)
    
    return app

app = create_app()

@app.route('/')
def home():
    """Main page route"""
    return render_template('index.html')

@app.route('/api/products')
def get_products():
    """API endpoint to get all products with optional filtering"""
    try:
        # Get query parameters
        category = request.args.get('category')
        search = request.args.get('search', '').strip()
        sort_by = request.args.get('sort', 'name')
        min_price = request.args.get('min_price', type=float)
        max_price = request.args.get('max_price', type=float)
        brands = request.args.getlist('brands')
        
        # Build query
        query = Product.query
        
        # Apply filters
        if category and category != 'All':
            query = query.filter(Product.category == category)
        
        if search:
            query = query.filter(Product.product_name.ilike(f'%{search}%'))
        
        if min_price is not None:
            query = query.filter(Product.amazon_price >= min_price)
        
        if max_price is not None:
            query = query.filter(Product.amazon_price <= max_price)
        
        # Apply sorting
        if sort_by == 'name':
            query = query.order_by(Product.product_name)
        elif sort_by == 'amazon-low':
            query = query.order_by(Product.amazon_price)
        elif sort_by == 'amazon-high':
            query = query.order_by(Product.amazon_price.desc())
        elif sort_by == 'flipkart-low':
            query = query.order_by(Product.flipkart_price)
        elif sort_by == 'flipkart-high':
            query = query.order_by(Product.flipkart_price.desc())
        
        products = query.all()
        
        # Convert to dict format
        products_data = []
        for product in products:
            products_data.append({
                'category': product.category,
                'productName': product.product_name,
                'amazonPrice': product.amazon_price,
                'amazonUrl': product.amazon_url,
                'flipkartPrice': product.flipkart_price,
                'flipkartUrl': product.flipkart_url
            })
        
        return jsonify(products_data)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/brands')
def get_brands():
    """API endpoint to get available brands by category"""
    try:
        category = request.args.get('category')
        
        query = db.session.query(Product.brand).distinct()
        if category and category != 'All':
            query = query.filter(Product.category == category)
        
        brands = [row[0] for row in query.all()]
        return jsonify(sorted(brands))
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/categories')
def get_categories():
    """API endpoint to get available categories"""
    try:
        categories = db.session.query(Product.category).distinct().all()
        return jsonify([cat[0] for cat in categories])
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True, host='0.0.0.0', port=5000)
