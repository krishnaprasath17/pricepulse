# PricePulse - Price Comparison Web Application

A Flask-based web application for comparing product prices across Amazon and Flipkart platforms. Built with Python, MySQL, and modern web technologies.

## Technology Stack

| **Category**    | **Technology Used**               |
| --------------- | --------------------------------- |
| Language        | Python                            |
| Libraries       | BeautifulSoup, Requests, Selenium |
| Framework       | Flask                             |
| Database        | MySQL                             |
| Frontend        | HTML, CSS, JS                     |
| IDE             | VS Code                           |
| Version Control | GitHub                            |
| Visualization   | Matplotlib, Chart.js              |

## Features

- **Product Comparison**: Compare prices across Amazon and Flipkart
- **Advanced Filtering**: Filter by category, brand, price range
- **Search Functionality**: Search products by name or brand
- **Sorting Options**: Sort by price, name, brand, or price difference
- **Product Comparison Modal**: Compare up to 4 products side by side
- **Responsive Design**: Mobile-friendly interface
- **Web Scraping**: Automated price updates using BeautifulSoup and Selenium
- **Data Visualization**: Price trends and comparisons using Matplotlib

## Installation

### Prerequisites

- Python 3.8 or higher
- MySQL 5.7 or higher
- Chrome browser (for Selenium web scraping)
- ChromeDriver (automatically managed by Selenium)

### Setup Instructions

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd PricePulse
   ```

2. **Create virtual environment**
   ```bash
   python -m venv venv
   
   # On Windows
   venv\Scripts\activate
   
   # On macOS/Linux
   source venv/bin/activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Setup MySQL database**
   ```sql
   CREATE DATABASE pricepulse;
   CREATE USER 'pricepulse_user'@'localhost' IDENTIFIED BY 'your_password';
   GRANT ALL PRIVILEGES ON pricepulse.* TO 'pricepulse_user'@'localhost';
   FLUSH PRIVILEGES;
   ```

5. **Configure environment variables**
   ```bash
   # Copy the environment template
   cp env_template.txt .env
   
   # Edit .env file with your configuration
   # Update database credentials, secret key, etc.
   ```

6. **Initialize the database**
   ```bash
   python seed_data.py
   ```

7. **Run the application**
   ```bash
   python app.py
   ```

8. **Access the application**
   Open your browser and navigate to `http://localhost:5000`

## Project Structure

```
PricePulse/
├── app.py                 # Main Flask application
├── models.py              # Database models
├── routes.py              # API routes
├── config.py              # Configuration settings
├── scraper.py             # Web scraping functionality
├── seed_data.py           # Database seeding script
├── requirements.txt       # Python dependencies
├── env_template.txt       # Environment variables template
├── README.md              # This file
├── templates/             # HTML templates
│   └── index.html         # Main page template
├── static/                # Static files
│   ├── css/
│   │   └── style.css      # Custom styles
│   ├── js/
│   │   └── app.js         # Frontend JavaScript
│   └── images/            # Image assets
└── attached_assets/       # Sample data and images
```

## API Endpoints

### Products
- `GET /api/products` - Get all products with optional filtering
- `GET /api/products/<id>` - Get specific product by ID
- `GET /api/brands` - Get available brands
- `GET /api/categories` - Get available categories

### Search & Comparison
- `GET /api/search` - Search products
- `POST /api/compare` - Compare multiple products

### Query Parameters for /api/products
- `category` - Filter by category (Phones, Laptops, Headphones)
- `search` - Search by product name
- `sort` - Sort by (name, brand, amazon-low, amazon-high, flipkart-low, flipkart-high, price-diff)
- `brands` - Filter by brands (can be used multiple times)
- `min_price` - Minimum price filter
- `max_price` - Maximum price filter

## Web Scraping

The application includes a comprehensive web scraping module that can:

- Search for products on Amazon and Flipkart
- Extract current prices and product information
- Update existing product prices in the database
- Handle rate limiting and anti-bot measures

### Usage Example
```python
from scraper import PriceComparisonScraper

scraper = PriceComparisonScraper()

# Search for products
results = scraper.search_products("iPhone 15", max_results_per_platform=5)

# Get price comparison for specific URLs
comparison = scraper.get_price_comparison(amazon_url, flipkart_url)
```

## Database Schema

### Products Table
- `id` - Primary key
- `category` - Product category (Phones, Laptops, Headphones)
- `product_name` - Product name
- `brand` - Brand name
- `amazon_price` - Amazon price
- `amazon_url` - Amazon product URL
- `flipkart_price` - Flipkart price
- `flipkart_url` - Flipkart product URL
- `created_at` - Creation timestamp
- `updated_at` - Last update timestamp

### Price History Table
- `id` - Primary key
- `product_id` - Foreign key to products table
- `amazon_price` - Amazon price at time of recording
- `flipkart_price` - Flipkart price at time of recording
- `recorded_at` - Timestamp of price recording

## Development

### Adding New Features

1. **New API Endpoints**: Add routes in `routes.py`
2. **Database Changes**: Update models in `models.py`
3. **Frontend Changes**: Modify templates and static files
4. **Scraping Logic**: Extend `scraper.py` for new platforms

### Testing

```bash
# Run with test configuration
FLASK_ENV=testing python app.py

# Run specific tests (if test files are created)
python -m pytest tests/
```

## Deployment

### Production Setup

1. **Environment Configuration**
   ```bash
   export FLASK_ENV=production
   export DATABASE_URL=mysql+pymysql://user:password@prod-db-host/pricepulse
   export SECRET_KEY=your-production-secret-key
   ```

2. **Database Migration**
   ```bash
   python seed_data.py
   ```

3. **Run with Production Server**
   ```bash
   # Using Gunicorn (recommended)
   pip install gunicorn
   gunicorn -w 4 -b 0.0.0.0:5000 app:app
   ```

### Docker Deployment (Optional)

```dockerfile
FROM python:3.9-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .
EXPOSE 5000

CMD ["gunicorn", "-w", "4", "-b", "0.0.0.0:5000", "app:app"]
```

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support and questions, please open an issue in the GitHub repository.

## Roadmap

- [ ] Add more e-commerce platforms (Myntra, Snapdeal, etc.)
- [ ] Implement price alerts and notifications
- [ ] Add user accounts and favorites
- [ ] Create price trend charts using Matplotlib
- [ ] Add product reviews and ratings
- [ ] Implement machine learning for price predictions
- [ ] Add mobile app support
- [ ] Implement advanced analytics dashboard

