#!/usr/bin/env python3
"""
Flipkart-only scraper that adds unique products to the local SQLite DB.

This avoids Amazon 503 issues and focuses on Flipkart search results.
"""
import time
import sys
import os
from difflib import SequenceMatcher

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from scraper import FlipkartScraper
from models import db, Product
from flask import Flask


def create_app_for_db():
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'scrape-seed-key'
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///pricepulse.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    db.init_app(app)
    return app


def similar(a: str, b: str) -> float:
    if not a or not b:
        return 0.0
    return SequenceMatcher(None, a.lower(), b.lower()).ratio()


def add_flipkart_item(fk_item, category):
    if not fk_item or not fk_item.get('title'):
        return False

    title = fk_item['title']
    price = fk_item.get('price')
    url = fk_item.get('url') or ''
    brand = title.split()[0]

    # Check for existing by url
    exists = db.session.query(Product).filter(Product.flipkart_url == url).first()
    if exists:
        return False

    # Fuzzy match by name
    for p in db.session.query(Product).all():
        if similar(p.product_name or '', title) > 0.9:
            return False

    if price is None:
        return False

    prod = Product(
        category=category,
        product_name=title,
        brand=brand,
        amazon_price=float(price),  # mirror price to amazon if amazon not present
        amazon_url='',
        flipkart_price=float(price),
        flipkart_url=url
    )

    db.session.add(prod)
    db.session.commit()
    return True


def main():
    fk = FlipkartScraper()
    app = create_app_for_db()

    queries = [
        ('Phones', ['best mobiles', 'budget phones', 'flagship phones', 'gaming phones']),
        ('Laptops', ['gaming laptop', 'thin laptop', 'laptop for students', 'work laptop']),
        ('Headphones', ['wireless earbuds', 'noise cancelling headphones', 'gaming headset', 'true wireless earbuds'])
    ]

    inserted = 0
    attempted = 0

    with app.app_context():
        for category, qs in queries:
            for q in qs:
                try:
                    attempted += 1
                    print(f"Flipkart search: '{q}' ({category})")
                    results = fk.search_product(q, max_results=8)
                    added_for_query = 0
                    for item in results:
                        ok = add_flipkart_item(item, category)
                        if ok:
                            inserted += 1
                            added_for_query += 1
                            print(f"  + Added: {item.get('title')}")
                        time.sleep(0.5)

                    if added_for_query == 0:
                        print("  - No new items added for this query")

                    time.sleep(1.5)

                except Exception as e:
                    print(f"Error searching '{q}': {e}")
                    time.sleep(2)

    print(f"Done. Attempted queries: {attempted}, Inserted items: {inserted}")


if __name__ == '__main__':
    main()
