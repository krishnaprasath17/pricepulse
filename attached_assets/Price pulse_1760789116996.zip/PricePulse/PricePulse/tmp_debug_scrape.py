from scraper import AmazonScraper
import os, bs4
os.environ['FORCE_SELENIUM']='1'
s = AmazonScraper()
c = s._fetch_url('https://www.amazon.in/s?k=laptop')
print('content_len', len(c) if c else 0)
if c:
    soup = bs4.BeautifulSoup(c, 'html.parser')
    cnt = len(soup.select('div[data-component-type="s-search-result"]'))
    print('search_results', cnt)
    el = soup.select_one('div[data-component-type="s-search-result"]')
    if el:
        print(el.prettify()[:3000])
else:
    print('no content')
