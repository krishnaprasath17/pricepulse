# PricePulse Setup Guide

## Python Installation Required

Your system doesn't have Python installed. Here's how to set it up:

### Step 1: Install Python

1. **Download Python**: Go to https://www.python.org/downloads/
2. **Choose Version**: Download Python 3.8 or higher (recommended: Python 3.11)
3. **Install**: Run the installer and **IMPORTANT**: Check "Add Python to PATH" during installation
4. **Verify**: Open Command Prompt and type `python --version`

### Step 2: Run PricePulse

Once Python is installed, you have several options:

#### Option A: Use the Batch File (Windows)
```bash
run.bat
```

#### Option B: Use PowerShell Script
```bash
.\run.ps1
```

#### Option C: Manual Installation
```bash
# Install dependencies
pip install Flask Flask-SQLAlchemy Flask-CORS

# Run the application
python run_app.py
```

#### Option D: Use the Full Application (with MySQL)
```bash
# Install all dependencies
pip install -r requirements.txt

# Set up MySQL database (see README.md for details)
# Run the main application
python app.py
```

### Step 3: Access the Application

Once running, open your browser and go to: **http://localhost:5000**

## Alternative: Demo Version

If you want to see the application without installing Python, I can create a static HTML version that demonstrates the functionality using sample data.

## Troubleshooting

### Python Not Found
- Make sure Python is added to PATH during installation
- Restart your terminal/command prompt after installation
- Try `py` instead of `python` on Windows

### Permission Issues
- Run terminal as Administrator
- For PowerShell: `Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser`

### Port Already in Use
- Change the port in `run_app.py` from 5000 to another number (e.g., 8080)
- Or stop any other applications using port 5000

## What's Included

The converted Flask application includes:

✅ **Complete Flask Backend**
- Product API endpoints
- Database models (SQLite for easy setup)
- Search and filtering functionality
- Product comparison features

✅ **Modern Frontend**
- Responsive Bootstrap design
- Interactive product filtering
- Comparison modal
- Mobile-friendly interface

✅ **Sample Data**
- Pre-loaded with phone, laptop, and headphone products
- Real Amazon and Flipkart URLs
- Price comparison data

✅ **Web Scraping Ready**
- BeautifulSoup and Selenium integration
- Amazon and Flipkart scrapers
- Price update functionality

## Next Steps

1. Install Python (if not done already)
2. Run the application using one of the methods above
3. Explore the features:
   - Browse products by category
   - Search and filter products
   - Compare up to 4 products
   - View price differences

The application is now fully converted from React/TypeScript to Python Flask and ready to use!
