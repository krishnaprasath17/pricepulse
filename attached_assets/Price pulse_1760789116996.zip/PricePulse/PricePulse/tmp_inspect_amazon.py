from scraper import AmazonScraper
import os, bs4
os.environ['FORCE_SELENIUM']='1'
A = AmazonScraper()
content = A._fetch_url('https://www.amazon.in/s?k=laptop')
print('content', bool(content))
if not content:
    raise SystemExit('no content')
soup = bs4.BeautifulSoup(content, 'html.parser')
container = soup.select_one('div[data-component-type="s-search-result"]')
print('container found', bool(container))
if not container:
    raise SystemExit('no container')

print('--- anchors ---')
for a in container.find_all('a', href=True)[:20]:
    cls = a.get('class')
    txt = a.get_text(strip=True)
    print('A class=', cls, ' href=', a.get('href')[:120], ' textlen=', len(txt), ' snippet=', txt[:80])

print('--- title spans ---')
for sel in ['span.a-size-medium.a-color-base.a-text-normal', 'span.a-size-base-plus.a-color-base.a-text-normal', 'h2', 'span.a-offscreen']:
    el = container.select_one(sel)
    print(sel, '->', bool(el), 'text=', (el.get_text(strip=True)[:120] if el else None))

print('--- price offscreen ---')
off = container.select_one('span.a-offscreen')
print('offscreen', bool(off), off.get_text(strip=True)[:80] if off else None)

print('--- whole price ---')
whole = container.select_one('span.a-price-whole')
print('whole', bool(whole), whole.get_text(strip=True)[:80] if whole else None)

print('\nFull snippet:\n')
print(container.prettify()[:4000])
