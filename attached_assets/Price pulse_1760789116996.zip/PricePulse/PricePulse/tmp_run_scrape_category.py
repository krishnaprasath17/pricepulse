from scraper import PriceComparisonScraper
import os
os.environ['FORCE_SELENIUM']='1'
sc = PriceComparisonScraper()
items = sc.scrape_category('laptops', max_per_platform=5)
print('parsed items:', len(items))
for i,it in enumerate(items[:10]):
    print(i+1, it['platform'], it['title'][:120], it.get('price'), it.get('url'))
