#!/usr/bin/env python3
"""
Simple Flask application runner
This version uses SQLite instead of MySQL for easier setup
"""

import os
import sys
from flask import Flask, render_template, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from datetime import datetime

# Create Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = 'dev-secret-key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///pricepulse.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize extensions
db = SQLAlchemy(app)
CORS(app)

# Simple Product model
class Product(db.Model):
    __tablename__ = 'products'
    
    id = db.Column(db.Integer, primary_key=True)
    category = db.Column(db.String(50), nullable=False, index=True)
    product_name = db.Column(db.String(255), nullable=False, index=True)
    brand = db.Column(db.String(100), nullable=True, index=True)
    amazon_price = db.Column(db.Float, nullable=False)
    amazon_url = db.Column(db.Text, nullable=False)
    flipkart_price = db.Column(db.Float, nullable=False)
    flipkart_url = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

# Routes
@app.route('/')
def home():
    """Main page route"""
    return render_template('index.html')

@app.route('/api/products')
def get_products():
    """API endpoint to get all products with optional filtering"""
    try:
        # Get query parameters
        category = request.args.get('category')
        search = request.args.get('search', '').strip()
        sort_by = request.args.get('sort', 'name')
        min_price = request.args.get('min_price', type=float)
        max_price = request.args.get('max_price', type=float)
        brands = request.args.getlist('brands')
        
        # Build query
        query = Product.query
        
        # Apply filters
        if category and category != 'All':
            query = query.filter(Product.category == category)
        
        if search:
            query = query.filter(Product.product_name.ilike(f'%{search}%'))
        
        if brands:
            query = query.filter(Product.brand.in_(brands))
        
        if min_price is not None:
            query = query.filter(Product.amazon_price >= min_price)
        
        if max_price is not None:
            query = query.filter(Product.amazon_price <= max_price)
        
        # Apply sorting
        if sort_by == 'name':
            query = query.order_by(Product.product_name)
        elif sort_by == 'brand':
            query = query.order_by(Product.brand, Product.product_name)
        elif sort_by == 'amazon-low':
            query = query.order_by(Product.amazon_price)
        elif sort_by == 'amazon-high':
            query = query.order_by(Product.amazon_price.desc())
        elif sort_by == 'flipkart-low':
            query = query.order_by(Product.flipkart_price)
        elif sort_by == 'flipkart-high':
            query = query.order_by(Product.flipkart_price.desc())
        elif sort_by == 'price-diff':
            query = query.order_by((Product.amazon_price - Product.flipkart_price).desc())
        
        products = query.all()
        
        # Convert to dict format
        products_data = []
        for product in products:
            products_data.append({
                'id': product.id,
                'category': product.category,
                'productName': product.product_name,
                'brand': product.brand,
                'amazonPrice': product.amazon_price,
                'amazonUrl': product.amazon_url,
                'flipkartPrice': product.flipkart_price,
                'flipkartUrl': product.flipkart_url
            })
        
        return jsonify(products_data)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/brands')
def get_brands():
    """API endpoint to get available brands by category"""
    try:
        category = request.args.get('category')
        
        query = db.session.query(Product.brand).distinct()
        if category and category != 'All':
            query = query.filter(Product.category == category)
        
        brands = [row[0] for row in query.all() if row[0]]
        return jsonify(sorted(brands))
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/categories')
def get_categories():
    """API endpoint to get available categories"""
    try:
        categories = db.session.query(Product.category).distinct().all()
        return jsonify([cat[0] for cat in categories])
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/compare', methods=['POST'])
def compare_products():
    """Compare multiple products"""
    try:
        data = request.get_json()
        product_ids = data.get('productIds', [])
        
        if len(product_ids) < 2 or len(product_ids) > 4:
            return jsonify({'error': 'Please select 2-4 products to compare'}), 400
        
        # Fetch products and preserve requested order
        products_map = {p.id: p for p in Product.query.filter(Product.id.in_(product_ids)).all()}
        missing = [pid for pid in product_ids if pid not in products_map]
        if missing:
            return jsonify({'error': 'Some products not found', 'missing': missing}), 404

        comparison_data = []
        # we'll track the overall best price among all products and platforms
        overall_best = None  # tuple (price, product_id, platform)

        for pid in product_ids:
            product = products_map[pid]
            # Safely extract prices (could be None)
            a_price = product.amazon_price if product.amazon_price is not None else None
            f_price = product.flipkart_price if product.flipkart_price is not None else None

            # Determine best platform and best price for this product
            if a_price is None and f_price is None:
                best_platform = 'Unknown'
                price_diff = None
                best_price = None
            elif a_price is None:
                best_platform = 'Flipkart'
                price_diff = None
                best_price = f_price
            elif f_price is None:
                best_platform = 'Amazon'
                price_diff = None
                best_price = a_price
            else:
                # both present
                if a_price < f_price:
                    best_platform = 'Amazon'
                elif f_price < a_price:
                    best_platform = 'Flipkart'
                else:
                    best_platform = 'Both'
                price_diff = abs(a_price - f_price)
                best_price = a_price if a_price <= f_price else f_price

            # Update overall best
            if best_price is not None:
                if overall_best is None or best_price < overall_best[0]:
                    overall_best = (best_price, product.id, best_platform)

            comparison_data.append({
                'id': product.id,
                'category': product.category,
                'productName': product.product_name,
                'brand': product.brand,
                'amazonPrice': a_price,
                'amazonUrl': product.amazon_url,
                'flipkartPrice': f_price,
                'flipkartUrl': product.flipkart_url,
                'priceDifference': price_diff,
                'bestPrice': best_price,
                'bestPlatform': best_platform
            })

        result = {'comparison': comparison_data}
        if overall_best is not None:
            result['overallBest'] = {
                'price': overall_best[0],
                'productId': overall_best[1],
                'platform': overall_best[2]
            }

        return jsonify(result)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def seed_sample_data():
    """Seed the database with real product data from your CSV"""
    sample_products = [
        # Phones
        {"category": "Phones", "product_name": "Samsung Galaxy M05", "brand": "Samsung", "amazon_price": 22999, "amazon_url": "https://www.amazon.in/Samsung-Galaxy-M05-Storage-Camera/dp/B0D5J8G9YJ", "flipkart_price": 21999, "flipkart_url": "https://www.flipkart.com/samsung-galaxy-m05-5g-ivy-green-128-gb/p/itm0d5c7d4d7b5e4"},
        {"category": "Phones", "product_name": "OnePlus Nord CE4 Lite 5G", "brand": "OnePlus", "amazon_price": 34999, "amazon_url": "https://www.amazon.in/OnePlus-Nord-CE4-Lite-5G/dp/B0D3M7J6K2", "flipkart_price": 33999, "flipkart_url": "https://www.flipkart.com/oneplus-nord-ce-4-lite-5g-mega-blue-128-gb/p/itm5f4b3a9c5e4d6"},
        {"category": "Phones", "product_name": "iQOO Z10 Lite 5G", "brand": "iQOO", "amazon_price": 15000, "amazon_url": "https://www.amazon.in/iQOO-Z10-Lite-5G-128GB/dp/B0D7K9L2M3", "flipkart_price": 14500, "flipkart_url": "https://www.flipkart.com/iqoo-z10-lite-5g-brushed-green-128-gb/p/itm6f8b3c4d7e5f2"},
        {"category": "Phones", "product_name": "Redmi 13 5G Prime Edition", "brand": "Redmi", "amazon_price": 19999, "amazon_url": "https://www.amazon.in/Redmi-13-5G-Prime-Edition/dp/B0D5H8G7YJ", "flipkart_price": 18999, "flipkart_url": "https://www.flipkart.com/redmi-13-5g-prime-edition-black-diamond-128-gb/p/itm0d5c7d4d7b5e4"},
        {"category": "Phones", "product_name": "iPhone 15", "brand": "Apple", "amazon_price": 47499, "amazon_url": "https://www.amazon.in/Apple-iPhone-15-128GB-Black/dp/B0CHX1W1X2", "flipkart_price": 46499, "flipkart_url": "https://www.flipkart.com/apple-iphone-15-black-128-gb/p/itm6f8b3c4d7e5f2"},
        {"category": "Phones", "product_name": "Samsung Galaxy A55 5G", "brand": "Samsung", "amazon_price": 35000, "amazon_url": "https://www.amazon.in/Samsung-Galaxy-A55-5G-128GB/dp/B0D3M7J6K2", "flipkart_price": 34000, "flipkart_url": "https://www.flipkart.com/samsung-galaxy-a55-5g-awesome-iceblue-128-gb/p/itm5f4b3a9c5e4d6"},
        {"category": "Phones", "product_name": "Pixel 9", "brand": "Google", "amazon_price": 53499, "amazon_url": "https://www.amazon.in/Google-Pixel-9-128GB-Obsidian/dp/B0D7K9L2M3", "flipkart_price": 52499, "flipkart_url": "https://www.flipkart.com/google-pixel-9-obsidian-128-gb/p/itm6f8b3c4d7e5f2"},
        {"category": "Phones", "product_name": "POCO F7", "brand": "POCO", "amazon_price": 29499, "amazon_url": "https://www.amazon.in/POCO-F7-5G-256GB/dp/B0D3M7J6K2", "flipkart_price": 28499, "flipkart_url": "https://www.flipkart.com/poco-f7-5g-titanium-special-edition-256-gb/p/itm5f4b3a9c5e4d6"},
        
        # Laptops
        {"category": "Laptops", "product_name": "HP 15-fd0467TU", "brand": "HP", "amazon_price": 50200, "amazon_url": "https://www.amazon.in/HP-15-fd0467TU-13th-Gen-i3-1315U/dp/B0D5J8G9YJ", "flipkart_price": 49200, "flipkart_url": "https://www.flipkart.com/hp-15-fd0467tu-intel-core-i3-13th-gen-1315u-8-gb-512-gb-ssd-windows-11-home-15-thin-light-laptop/p/itm0d5c7d4d7b5e4"},
        {"category": "Laptops", "product_name": "Dell 15 2025", "brand": "Dell", "amazon_price": 40000, "amazon_url": "https://www.amazon.in/Dell-Inspiron-15-2025-i5-1235U/dp/B0D3M7J6K2", "flipkart_price": 39000, "flipkart_url": "https://www.flipkart.com/dell-inspiron-15-2025-intel-core-i5-12th-gen-1235u-16-gb-512-gb-ssd-windows-11-home-thin-light-laptop/p/itm5f4b3a9c5e4d6"},
        {"category": "Laptops", "product_name": "Apple MacBook Air M4", "brand": "Apple", "amazon_price": 84990, "amazon_url": "https://www.amazon.in/Apple-MacBook-Air-13-inch-M3/dp/B0D5J8G9YJ", "flipkart_price": 83990, "flipkart_url": "https://www.flipkart.com/apple-2025-macbook-air-m3-apple-m3-8-gb-256-gb-ssd-mac-os-m3-13-6-inch-ultra-thin-light-laptop/p/itm5f4b3a9c5e4d6"},
        {"category": "Laptops", "product_name": "Lenovo ThinkBook 16", "brand": "Lenovo", "amazon_price": 45000, "amazon_url": "https://www.amazon.in/Lenovo-ThinkBook-16-G7-ISP-21KC000VIN/dp/B0D7K9L2M3", "flipkart_price": 44000, "flipkart_url": "https://www.flipkart.com/lenovo-thinkbook-16-g7-isp-intel-core-i5-12th-gen-1235u-16-gb-512-gb-ssd-windows-11-home-thin-light-laptop/p/itm6f8b3c4d7e5f2"},
        {"category": "Laptops", "product_name": "ASUS Vivobook 15", "brand": "ASUS", "amazon_price": 35000, "amazon_url": "https://www.amazon.in/ASUS-Vivobook-15-X1504VA-NJ342WS/dp/B0D5H8G7YJ", "flipkart_price": 34000, "flipkart_url": "https://www.flipkart.com/asus-vivobook-15-2025-x1504va-nj342ws-intel-core-i3-13th-gen-1315u-8-gb-512-gb-ssd-windows-11-home-thin-light-laptop/p/itm0d5c7d4d7b5e4"},
        {"category": "Laptops", "product_name": "MacBook Pro M3", "brand": "Apple", "amazon_price": 120000, "amazon_url": "https://www.amazon.in/Apple-MacBook-Pro-14-inch-M3/dp/B0D7K9L2M3", "flipkart_price": 118000, "flipkart_url": "https://www.flipkart.com/apple-2025-macbook-pro-m3-apple-m3-8-gb-512-gb-ssd-mac-os-m3-14-2-inch-ultra-thin-light-laptop/p/itm6f8b3c4d7e5f2"},
        
        # Headphones
        {"category": "Headphones", "product_name": "GOBOULT Z40", "brand": "GOBOULT", "amazon_price": 1000, "amazon_url": "https://www.amazon.in/GOBOULT-Z40-Wireless-Headphones-Playtime/dp/B0D5J8G9YJ", "flipkart_price": 900, "flipkart_url": "https://www.flipkart.com/goboult-z40-wireless-headphones-60-h-playtime-zen-enc-mic-type-c-fast-charging-4-eq-modes-ipx5/p/itm0d5c7d4d7b5e4"},
        {"category": "Headphones", "product_name": "boAt Airdopes 141 ANC", "brand": "boAt", "amazon_price": 2000, "amazon_url": "https://www.amazon.in/boAt-Airdopes-141-ANC-Earbuds/dp/B0D3M7J6K2", "flipkart_price": 1900, "flipkart_url": "https://www.flipkart.com/boat-airdopes-141-anc-truly-wireless-bluetooth-v5-3-earbuds-42h-playtime-quad-mics-enc-anc-50ms-latency-ipx5-13mm-drivers-black/p/itm5f4b3a9c5e4d6"},
        {"category": "Headphones", "product_name": "Sony WH-CH520", "brand": "Sony", "amazon_price": 3000, "amazon_url": "https://www.amazon.in/Sony-WH-CH520-Wireless-Headphones-Bluetooth/dp/B0BTMRVJ8D", "flipkart_price": 2900, "flipkart_url": "https://www.flipkart.com/sony-wh-ch520-wireless-headphones-bluetooth-5-2-50-hours-battery-life-20mm-drivers-multi-point-connection-quick-charge-dsee-quick-folding-design-various-colours-black/p/itm5f4b3a9c5e4d6"},
        {"category": "Headphones", "product_name": "Apple AirPods 2", "brand": "Apple", "amazon_price": 10000, "amazon_url": "https://www.amazon.in/Apple-AirPods-2nd-Generation-Case/dp/B07PZF4R7G", "flipkart_price": 9900, "flipkart_url": "https://www.flipkart.com/apple-airpods-2nd-generation-bluetooth-headset-5-0-truly-wireless-m13-chip-5-hrs-play-time-total-upto-24-hrs-with-case-lightning-charging-case-wired-charging-mic/p/itm5f4b3a9c5e4d6"},
        {"category": "Headphones", "product_name": "Bose QuietComfort 45", "brand": "Bose", "amazon_price": 15000, "amazon_url": "https://www.amazon.in/Bose-QuietComfort-45-Bluetooth-Headphones/dp/B098FKXT8L", "flipkart_price": 14900, "flipkart_url": "https://www.flipkart.com/bose-quietcomfort-45-wireless-headphones-bluetooth-5-1-upto-24-hrs-battery-life-adaptive-noise-cancellation-voice-assistant-customizable-eq-touch-controls-black/p/itm6f8b3c4d7e5f2"},
        {"category": "Headphones", "product_name": "Sony WH-1000XM5", "brand": "Sony", "amazon_price": 20000, "amazon_url": "https://www.amazon.in/Sony-WH-1000XM5-Cancelling-Headphones-Headphone/dp/B09XS7JYH8", "flipkart_price": 19900, "flipkart_url": "https://www.flipkart.com/sony-wh-1000xm5-wireless-headphones-bluetooth-nc-aptx-adaptive-ldac-anc-30h-battery-life-quick-charge-touch-sensor-controls-speak-to-chat-wear-detection-black/p/itm0d5c7d4d7b5e4"}
    ]
    
    # Clear existing data and add sample data
    Product.query.delete()
    for product_data in sample_products:
        product = Product(**product_data)
        db.session.add(product)
    db.session.commit()
    print(f"Seeded database with {len(sample_products)} sample products")

if __name__ == '__main__':
    with app.app_context():
        # Create tables
        db.create_all()
        
        # Check if we have any products, if not seed sample data
        if Product.query.count() == 0:
            seed_sample_data()
    
    print("Starting PricePulse Flask application...")
    print("Open your browser and navigate to: http://localhost:5000")
    print("Press Ctrl+C to stop the server")
    
    # Disable the automatic reloader when starting from an automated background process
    # so the process doesn't immediately exit and we can connect reliably.
    app.run(debug=True, host='0.0.0.0', port=5000, use_reloader=False)
