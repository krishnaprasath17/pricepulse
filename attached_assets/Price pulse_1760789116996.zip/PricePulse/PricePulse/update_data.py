#!/usr/bin/env python3
"""
Update the Flask application with the real product data from the CSV file
"""

import csv
import re
from flask import Flask
from flask_sqlalchemy import SQLAlchemy

# Create Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = 'update-key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///pricepulse.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize database
db = SQLAlchemy(app)

# Product model
class Product(db.Model):
    __tablename__ = 'products'
    
    id = db.Column(db.Integer, primary_key=True)
    category = db.Column(db.String(50), nullable=False, index=True)
    product_name = db.Column(db.String(255), nullable=False, index=True)
    brand = db.Column(db.String(100), nullable=True, index=True)
    amazon_price = db.Column(db.Float, nullable=False)
    amazon_url = db.Column(db.Text, nullable=False)
    flipkart_price = db.Column(db.Float, nullable=False)
    flipkart_url = db.Column(db.Text, nullable=False)

def extract_brand(product_name):
    """Extract brand name from product name"""
    # Common brand patterns
    brands = [
        'Samsung', 'Apple', 'OnePlus', 'Xiaomi', 'Redmi', 'POCO', 'Realme', 'iQOO', 'vivo', 
        'Oppo', 'Motorola', 'Moto', 'Nothing', 'CMF', 'Infinix', 'Tecno', 'Honor', 'Huawei',
        'HP', 'Dell', 'Lenovo', 'ASUS', 'Acer', 'MSI', 'Microsoft', 'Razer', 'Alienware',
        'Gigabyte', 'Sony', 'JBL', 'Bose', 'Sennheiser', 'Audio-Technica', 'Beyerdynamic',
        'AKG', 'HyperX', 'SteelSeries', 'Logitech', 'Corsair', 'Turtle Beach', 'Astro',
        'Plantronics', 'boAt', 'Noise', 'Mivi', 'Fire-Boltt', 'pTron', 'Boult Audio',
        'Fastrack', 'Zebronics', 'Aroma', 'Caidea', 'TECHFIRE', 'GOBOULT', 'Google', 'Pixel',
        'Lava', 'realme'
    ]
    
    for brand in brands:
        if brand.lower() in product_name.lower():
            return brand
    
    # If no brand found, return first word
    return product_name.split()[0] if product_name.split() else 'Unknown'

def update_database():
    """Update the database with real product data"""
    csv_file = 'attached_assets/Pasted-Category-Product-Name-Amazon-Price-Amazon-URL-Flipkart-Price-Flipkart-URL-Phones-Samsung-Galaxy-M05-1759997348000_1759997348001.txt'
    
    with app.app_context():
        # Create tables
        db.create_all()
        
        # Clear existing data
        Product.query.delete()
        
        # Read CSV data
        products_added = 0
        with open(csv_file, 'r', encoding='utf-8') as file:
            csv_reader = csv.DictReader(file)
            
            for row in csv_reader:
                try:
                    # Extract data from CSV
                    category = row['Category'].strip()
                    product_name = row['Product_Name'].strip()
                    amazon_price = float(row['Amazon_Price'].replace(',', ''))
                    amazon_url = row['Amazon_URL'].strip()
                    flipkart_price = float(row['Flipkart_Price'].replace(',', ''))
                    flipkart_url = row['Flipkart_URL'].strip()
                    
                    # Extract brand
                    brand = extract_brand(product_name)
                    
                    # Create product
                    product = Product(
                        category=category,
                        product_name=product_name,
                        brand=brand,
                        amazon_price=amazon_price,
                        amazon_url=amazon_url,
                        flipkart_price=flipkart_price,
                        flipkart_url=flipkart_url
                    )
                    
                    db.session.add(product)
                    products_added += 1
                    
                except Exception as e:
                    print(f"Error processing row {row}: {e}")
                    continue
        
        # Commit changes
        db.session.commit()
        
        print(f"✅ Successfully updated database with {products_added} products")
        
        # Display statistics
        categories = db.session.query(Product.category).distinct().all()
        brands = db.session.query(Product.brand).distinct().all()
        
        print(f"📊 Categories: {[cat[0] for cat in categories]}")
        print(f"🏷️  Total Brands: {len(brands)}")
        
        # Show product count by category
        for category in categories:
            count = Product.query.filter_by(category=category[0]).count()
            print(f"   {category[0]}: {count} products")

if __name__ == '__main__':
    update_database()
