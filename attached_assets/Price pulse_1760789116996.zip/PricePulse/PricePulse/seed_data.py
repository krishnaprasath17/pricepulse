#!/usr/bin/env python3
"""
Data seeder script to populate the database with product data
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from models import db, Product

def create_app_for_seeding():
    from flask import Flask
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'seed-key'
    app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:password@localhost/pricepulse'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    db.init_app(app)
    return app

app = create_app_for_seeding()
import re

# Sample product data (converted from the original TypeScript data)
SAMPLE_PRODUCTS = [
    {
        "category": "Phones",
        "product_name": "Samsung Galaxy M05",
        "brand": "Samsung",
        "amazon_price": 22999,
        "amazon_url": "https://www.amazon.in/Samsung-Galaxy-M05-Storage-Camera/dp/B0D5J8G9YJ",
        "flipkart_price": 21999,
        "flipkart_url": "https://www.flipkart.com/samsung-galaxy-m05-5g-ivy-green-128-gb/p/itm0d5c7d4d7b5e4"
    },
    {
        "category": "Phones",
        "product_name": "OnePlus Nord CE4 Lite 5G",
        "brand": "OnePlus",
        "amazon_price": 34999,
        "amazon_url": "https://www.amazon.in/OnePlus-Nord-CE4-Lite-5G/dp/B0D3M7J6K2",
        "flipkart_price": 33999,
        "flipkart_url": "https://www.flipkart.com/oneplus-nord-ce-4-lite-5g-mega-blue-128-gb/p/itm5f4b3a9c5e4d6"
    },
    {
        "category": "Phones",
        "product_name": "iPhone 15",
        "brand": "Apple",
        "amazon_price": 47499,
        "amazon_url": "https://www.amazon.in/Apple-iPhone-15-128GB-Black/dp/B0CHX1W1X2",
        "flipkart_price": 46499,
        "flipkart_url": "https://www.flipkart.com/apple-iphone-15-black-128-gb/p/itm6f8b3c4d7e5f2"
    },
    {
        "category": "Laptops",
        "product_name": "HP 15-fd0467TU",
        "brand": "HP",
        "amazon_price": 50200,
        "amazon_url": "https://www.amazon.in/HP-15-fd0467TU-13th-Gen-i3-1315U/dp/B0D5J8G9YJ",
        "flipkart_price": 49200,
        "flipkart_url": "https://www.flipkart.com/hp-15-fd0467tu-intel-core-i3-13th-gen-1315u-8-gb-512-gb-ssd-windows-11-home-15-thin-light-laptop/p/itm0d5c7d4d7b5e4"
    },
    {
        "category": "Laptops",
        "product_name": "Dell 15 2025",
        "brand": "Dell",
        "amazon_price": 40000,
        "amazon_url": "https://www.amazon.in/Dell-Inspiron-15-2025-i5-1235U/dp/B0D3M7J6K2",
        "flipkart_price": 39000,
        "flipkart_url": "https://www.flipkart.com/dell-inspiron-15-2025-intel-core-i5-12th-gen-1235u-16-gb-512-gb-ssd-windows-11-home-thin-light-laptop/p/itm5f4b3a9c5e4d6"
    },
    {
        "category": "Laptops",
        "product_name": "Apple MacBook Air M4",
        "brand": "Apple",
        "amazon_price": 84990,
        "amazon_url": "https://www.amazon.in/Apple-MacBook-Air-13-inch-M3/dp/B0D5J8G9YJ",
        "flipkart_price": 83990,
        "flipkart_url": "https://www.flipkart.com/apple-2025-macbook-air-m3-apple-m3-8-gb-256-gb-ssd-mac-os-m3-13-6-inch-ultra-thin-light-laptop/p/itm5f4b3a9c5e4d6"
    },
    {
        "category": "Headphones",
        "product_name": "GOBOULT Z40",
        "brand": "GOBOULT",
        "amazon_price": 1000,
        "amazon_url": "https://www.amazon.in/GOBOULT-Z40-Wireless-Headphones-Playtime/dp/B0D5J8G9YJ",
        "flipkart_price": 900,
        "flipkart_url": "https://www.flipkart.com/goboult-z40-wireless-headphones-60-h-playtime-zen-enc-mic-type-c-fast-charging-4-eq-modes-ipx5/p/itm0d5c7d4d7b5e4"
    },
    {
        "category": "Headphones",
        "product_name": "Sony WH-CH520",
        "brand": "Sony",
        "amazon_price": 3000,
        "amazon_url": "https://www.amazon.in/Sony-WH-CH520-Wireless-Headphones-Bluetooth/dp/B0BTMRVJ8D",
        "flipkart_price": 2900,
        "flipkart_url": "https://www.flipkart.com/sony-wh-ch520-wireless-headphones-bluetooth-5-2-50-hours-battery-life-20mm-drivers-multi-point-connection-quick-charge-dsee-quick-folding-design-various-colours-black/p/itm5f4b3a9c5e4d6"
    },
    {
        "category": "Headphones",
        "product_name": "Apple AirPods 2",
        "brand": "Apple",
        "amazon_price": 10000,
        "amazon_url": "https://www.amazon.in/Apple-AirPods-2nd-Generation-Case/dp/B07PZF4R7G",
        "flipkart_price": 9900,
        "flipkart_url": "https://www.flipkart.com/apple-airpods-2nd-generation-bluetooth-headset-5-0-truly-wireless-m13-chip-5-hrs-play-time-total-upto-24-hrs-with-case-lightning-charging-case-wired-charging-mic/p/itm5f4b3a9c5e4d6"
    }
]

def extract_brand(product_name):
    """Extract brand name from product name"""
    # Common brand patterns
    brands = [
        'Samsung', 'Apple', 'OnePlus', 'Xiaomi', 'Redmi', 'POCO', 'Realme', 'iQOO', 'vivo', 
        'Oppo', 'Motorola', 'Moto', 'Nothing', 'CMF', 'Infinix', 'Tecno', 'Honor', 'Huawei',
        'HP', 'Dell', 'Lenovo', 'ASUS', 'Acer', 'MSI', 'Microsoft', 'Razer', 'Alienware',
        'Gigabyte', 'Sony', 'JBL', 'Bose', 'Sennheiser', 'Audio-Technica', 'Beyerdynamic',
        'AKG', 'HyperX', 'SteelSeries', 'Logitech', 'Corsair', 'Turtle Beach', 'Astro',
        'Plantronics', 'boAt', 'Noise', 'Mivi', 'Fire-Boltt', 'pTron', 'Boult Audio',
        'Fastrack', 'Zebronics', 'Aroma', 'Caidea', 'TECHFIRE', 'GOBOULT'
    ]
    
    for brand in brands:
        if brand.lower() in product_name.lower():
            return brand
    
    # If no brand found, return first word
    return product_name.split()[0] if product_name.split() else 'Unknown'

def seed_database():
    """Seed the database with sample product data"""
    with app.app_context():
        # Create tables
        db.create_all()
        
        # Clear existing data
        Product.query.delete()
        
        # Add sample products
        for product_data in SAMPLE_PRODUCTS:
            # Extract brand if not provided
            if 'brand' not in product_data or not product_data['brand']:
                product_data['brand'] = extract_brand(product_data['product_name'])
            
            product = Product(**product_data)
            db.session.add(product)
        
        # Commit changes
        db.session.commit()
        
        print(f"Successfully seeded database with {len(SAMPLE_PRODUCTS)} products")
        
        # Display some statistics
        categories = db.session.query(Product.category).distinct().all()
        brands = db.session.query(Product.brand).distinct().all()
        
        print(f"Categories: {[cat[0] for cat in categories]}")
        print(f"Brands: {[brand[0] for brand in brands]}")

if __name__ == '__main__':
    seed_database()
