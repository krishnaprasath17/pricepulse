from scraper import AmazonScraper
import os
os.environ['FORCE_SELENIUM']='1'
A = AmazonScraper()
res = A.search_product('laptop', max_results=8)
print('found', len(res))
for i,r in enumerate(res):
    print(i+1, r.get('title')[:140], r.get('price'), r.get('url'))
