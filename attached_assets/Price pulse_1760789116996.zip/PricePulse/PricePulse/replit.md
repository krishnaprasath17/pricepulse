# PriceCompare - Product Price Comparison Platform

## Overview

PriceCompare is a web application that helps users find the best deals on electronics (phones, laptops, and headphones) by comparing prices between Amazon and Flipkart. The platform provides filtering, sorting, and side-by-side product comparison features to help users make informed purchasing decisions.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack:**
- **Framework**: React with TypeScript
- **Routing**: Wouter (lightweight client-side routing)
- **State Management**: React hooks (useState, useMemo) for local state
- **Data Fetching**: TanStack Query (React Query) for async state management
- **Styling**: Tailwind CSS with custom design system
- **UI Components**: Radix UI primitives with custom shadcn/ui components

**Design System:**
- Based on Material Design principles with e-commerce visual enhancements
- Inspired by Amazon/Flipkart card aesthetics for familiar user patterns
- Custom color palette supporting light/dark themes
- Theme toggle functionality with localStorage persistence
- Typography using Inter font family
- Responsive layout with mobile-first approach

**Key Features:**
- Category-based filtering (Phones, Laptops, Headphones)
- Brand/model filtering with dynamic brand extraction
- Price range filtering using slider component
- Multiple sorting options (by name, brand, price differences, platform-specific pricing)
- Product search functionality
- Side-by-side product comparison (up to 4 products)
- Real-time savings calculation and display

### Backend Architecture

**Technology Stack:**
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **Build Tool**: esbuild for production builds
- **Development**: tsx for TypeScript execution in development

**Current Implementation:**
- RESTful API structure (route handlers in `/api` prefix)
- In-memory storage implementation (MemStorage class)
- Modular route registration system
- Custom error handling middleware
- Request logging with response tracking

**Data Layer:**
- Storage abstraction through IStorage interface
- Currently using in-memory storage (Map-based)
- Prepared for database integration with Drizzle ORM
- Schema definitions using Zod for validation

### Data Storage

**Planned Database:**
- PostgreSQL via Neon serverless (@neondatabase/serverless)
- Drizzle ORM for type-safe database operations
- Migration system configured in drizzle.config.ts
- Schema defined in shared/schema.ts

**Current Data Model:**
- Product schema with categories (Phones, Laptops, Headphones)
- Price comparison data (Amazon vs Flipkart)
- Product URLs for both platforms
- Brand extraction logic for filtering

**Data Flow:**
- Mock product data currently stored in client/src/lib/productData.ts
- Shared schema definitions in shared/schema.ts using Zod
- Brand extraction utilities in client/src/lib/brandUtils.ts

### External Dependencies

**Third-Party UI Libraries:**
- Radix UI (@radix-ui/*) - Accessible UI primitives for dialogs, dropdowns, sliders, tooltips, etc.
- class-variance-authority - Component variant management
- tailwind-merge & clsx - Utility class merging
- cmdk - Command palette/search component
- embla-carousel-react - Carousel functionality
- react-icons - Icon library (Amazon/Flipkart logos)
- lucide-react - Icon system

**Data & State Management:**
- @tanstack/react-query - Server state management
- react-hook-form - Form handling
- @hookform/resolvers - Form validation resolvers
- zod - Schema validation
- drizzle-zod - Drizzle to Zod schema conversion

**Database & Backend:**
- @neondatabase/serverless - PostgreSQL serverless driver
- drizzle-orm - Type-safe ORM
- express - Web framework
- connect-pg-simple - PostgreSQL session store

**Development Tools:**
- Vite - Build tool and dev server
- @vitejs/plugin-react - React plugin for Vite
- @replit/vite-plugin-* - Replit-specific development plugins
- TypeScript - Type safety
- PostCSS & Autoprefixer - CSS processing

**Utilities:**
- date-fns - Date manipulation
- wouter - Lightweight routing
- nanoid - Unique ID generation

**Design & Assets:**
- Stock images stored in attached_assets/stock_images/
- Category-specific images for phones, laptops, headphones
- Google Fonts (Inter, DM Sans, Fira Code, Geist Mono, Architects Daughter)