"""HTTP client wrapper with rotating proxies, throttling and retries.

This module provides a Requests-based client that supports:
- custom headers (including rotating user-agents),
- optional rotating proxies list,
- per-host throttling (simple sleep-based),
- exponential backoff retries for transient errors.

Usage:
    client = HttpClient(proxies=[...])
    resp = client.get(url)
"""
from __future__ import annotations

import time
import random
import threading
from typing import Optional, Dict, Any, List
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


DEFAULT_USER_AGENTS = [
    # A small set of common UA strings; expand as needed
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 13_0) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Safari/605.1.15',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:115.0) Gecko/20100101 Firefox/115.0'
]


class Throttle:
    def __init__(self, min_interval_seconds: float = 1.0):
        self.min_interval = min_interval_seconds
        self.lock = threading.Lock()
        self.last_called: Dict[str, float] = {}

    def wait(self, host: str):
        with self.lock:
            now = time.time()
            last = self.last_called.get(host, 0)
            wait_for = self.min_interval - (now - last)
            if wait_for > 0:
                time.sleep(wait_for)
            self.last_called[host] = time.time()


class HttpClient:
    def __init__(self, proxies: Optional[List[str]] = None, min_interval_seconds: float = 1.0, timeout: int = 15):
        self.proxies = proxies or []
        self.timeout = timeout
        self.throttle = Throttle(min_interval_seconds)

        self.session = requests.Session()
        # Configure retries for idempotent requests
        retries = Retry(total=3, backoff_factor=1, status_forcelist=(429, 500, 502, 503, 504))
        self.session.mount('https://', HTTPAdapter(max_retries=retries))
        self.session.mount('http://', HTTPAdapter(max_retries=retries))

    def _choose_proxy(self) -> Optional[Dict[str, str]]:
        if not self.proxies:
            return None
        p = random.choice(self.proxies)
        return {'http': p, 'https': p}

    def _default_headers(self) -> Dict[str, str]:
        return {
            'User-Agent': random.choice(DEFAULT_USER_AGENTS),
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.9'
        }

    def get(self, url: str, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, **kwargs) -> requests.Response:
        host = requests.utils.urlparse(url).netloc
        self.throttle.wait(host)

        h = self._default_headers()
        if headers:
            h.update(headers)

        proxy = self._choose_proxy()

        resp = self.session.get(url, params=params, headers=h, timeout=self.timeout, proxies=proxy, **kwargs)
        return resp

    def post(self, url: str, data: Any = None, json: Any = None, headers: Optional[Dict[str, str]] = None, **kwargs) -> requests.Response:
        host = requests.utils.urlparse(url).netloc
        self.throttle.wait(host)

        h = self._default_headers()
        if headers:
            h.update(headers)

        proxy = self._choose_proxy()
        resp = self.session.post(url, data=data, json=json, headers=h, timeout=self.timeout, proxies=proxy, **kwargs)
        return resp


__all__ = ['HttpClient']
