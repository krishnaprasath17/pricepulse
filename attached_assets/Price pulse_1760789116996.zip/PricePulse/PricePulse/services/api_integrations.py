"""
API integration adapters for Amazon and Flipkart.

This module tries to use official APIs when credentials are provided via environment
variables. Otherwise it exposes a fallback that uses the project's scraper but
through the HttpClient wrapper (throttling, retries, proxies).

Add your keys to environment variables to enable official adapters.
"""
import os
from typing import Optional, Dict, Any, List

from services.http_client import HttpClient

# Optional import of existing scraper fallback
try:
    from scraper import PriceComparisonScraper
except Exception:
    PriceComparisonScraper = None

# Optional import for Amazon PA-API wrapper (third-party). We keep it optional so
# the project can run without the dependency; if present we'll use it when keys
# are provided.
try:
    # 'python-amazon-paapi' is a commonly used wrapper; adapt if you use another
    from amazon_paapi import AmazonApi, AmazonApiException
except Exception:
    AmazonApi = None
    AmazonApiException = Exception

HTTP_CLIENT = HttpClient(min_interval_seconds=float(os.environ.get('REQUEST_DELAY_SECONDS', '1.0')),
                         proxies=(os.environ.get('ROTATING_PROXIES', '') or '').split(',') if os.environ.get('ROTATING_PROXIES') else None)


def has_amazon_keys() -> bool:
    return bool(os.environ.get('AMAZON_ACCESS_KEY') and os.environ.get('AMAZON_SECRET_KEY') and os.environ.get('AMAZON_ASSOCIATE_TAG'))


def has_flipkart_keys() -> bool:
    return bool(os.environ.get('FLIPKART_AFFILIATE_ID') and os.environ.get('FLIPKART_AFFILIATE_TOKEN'))


def search_amazon(query: str, max_results: int = 5) -> List[Dict[str, Any]]:
    """Search Amazon using official PA-API when available; otherwise fallback to scraper."""
    if has_amazon_keys():
        if AmazonApi is None:
            # Library missing — raise with instructions so the operator can install it or unset keys
            raise RuntimeError('Amazon PA-API keys are present but the optional `amazon_paapi` library is not installed. Install it or unset AMAZON_* env vars to use scraper fallback')

        # Build the client using env vars
        access_key = os.environ.get('AMAZON_ACCESS_KEY')
        secret_key = os.environ.get('AMAZON_SECRET_KEY')
        associate_tag = os.environ.get('AMAZON_ASSOCIATE_TAG')
        country = os.environ.get('AMAZON_MARKETPLACE', 'IN')  # Default to India marketplace

        try:
            api = AmazonApi(access_key, secret_key, associate_tag, country)
            # The library's search_items call may vary; use generic call and map results
            resp = api.search_items(keywords=query, item_count=max_results)
            items = []
            # Map the response to the project's expected dict shape with richer fields
            for it in getattr(resp, 'items', []) or []:
                try:
                    # title
                    title = None
                    if getattr(it, 'item_info', None) and getattr(it.item_info, 'title', None):
                        title = getattr(it.item_info.title, 'display_value', None)
                    title = title or getattr(it, 'title', None) or getattr(it, 'name', None)

                    # ASIN / identifier
                    asin = getattr(it, 'asin', None) or getattr(it, 'id', None)

                    # price
                    price = None
                    offers = getattr(it, 'offers', None)
                    if offers and getattr(offers, 'listings', None):
                        listing = offers.listings[0]
                        # try several locations for price
                        price = None
                        if getattr(listing, 'price', None):
                            price = getattr(listing.price, 'amount', None) or getattr(listing.price, 'display_amount', None)
                        elif getattr(listing, 'saving', None):
                            price = getattr(listing.saving, 'amount', None)
                        try:
                            price = float(price) if price is not None else None
                        except Exception:
                            price = None

                    # image
                    image = None
                    if getattr(it, 'images', None):
                        try:
                            image = it.images.primary.large.url
                        except Exception:
                            image = None

                    url = getattr(it, 'detail_page_url', None) or getattr(it, 'detail_page', None) or None

                    brand = None
                    if getattr(it, 'item_info', None) and getattr(it.item_info, 'by_line_info', None):
                        brand = getattr(it.item_info.by_line_info, 'brand', None)
                        if brand:
                            brand = getattr(brand, 'display_value', None) or brand

                    items.append({
                        'title': title,
                        'price': price,
                        'url': url,
                        'platform': 'Amazon',
                        'asin': asin,
                        'image': image,
                        'brand': brand,
                        'source': 'amazon_api'
                    })
                except Exception:
                    continue
            return items[:max_results]
        except AmazonApiException as e:
            # If the API fails, gracefully fallback to scraper when possible
            if PriceComparisonScraper is not None:
                scraper = PriceComparisonScraper()
                return scraper.amazon_scraper.search_product(query, max_results)
            raise

    # Fallback to scraper
    if PriceComparisonScraper is None:
        return []
    scraper = PriceComparisonScraper()
    return scraper.amazon_scraper.search_product(query, max_results)


def search_flipkart(query: str, max_results: int = 5) -> List[Dict[str, Any]]:
    """Search Flipkart using official Affiliate API when available; otherwise fallback to scraper."""
    if has_flipkart_keys():
        # Implementing Flipkart Affiliate API integration is project-specific because
        # Flipkart's affiliate program returns XML/JSON via specific endpoints and
        # requires affiliate ID/token. We attempt a minimal, safe implementation
        # using the HTTP client if keys are present. If you need a more complete
        # integration, replace this block with your provider client.

        affiliate_id = os.environ.get('FLIPKART_AFFILIATE_ID')
        affiliate_token = os.environ.get('FLIPKART_AFFILIATE_TOKEN')
        # Example Flipkart affiliate search endpoint (may differ; check docs)
        search_url = f"https://affiliate-api.flipkart.net/affiliate/search/json?query={query}"
        try:
            resp = HTTP_CLIENT.get(search_url, headers={'Fk-Affiliate-Id': affiliate_id, 'Fk-Affiliate-Token': affiliate_token})
            if resp.status_code != 200:
                raise RuntimeError(f'Flipkart affiliate API returned {resp.status_code}')
            # Flipkart affiliate API can return different shapes; be tolerant
            try:
                data = resp.json()
            except Exception:
                data = {}

            items = []
            # Some affiliate responses wrap products under 'productInfoList' or 'products'
            hits = data.get('productInfoList') or data.get('products') or data.get('productsList') or []
            # Normalize different shapes
            normalized_hits = []
            for h in hits:
                if isinstance(h, dict) and 'productBaseInfoV1' in h:
                    normalized_hits.append(h['productBaseInfoV1'])
                elif isinstance(h, dict) and 'product' in h:
                    normalized_hits.append(h['product'])
                else:
                    normalized_hits.append(h)

            for hit in normalized_hits[:max_results]:
                try:
                    title = None
                    price = 0
                    url = None
                    brand = None
                    image = None

                    if isinstance(hit, dict):
                        # productBaseInfoV1 is common in some Flipkart affiliate payloads
                        info = hit.get('productBaseInfoV1', hit)
                        title = info.get('title') or info.get('productTitle') or info.get('name')
                        mrp = info.get('maximumRetailPrice') or info.get('price') or {}
                        try:
                            price = float(mrp.get('amount') or mrp.get('value') or 0)
                        except Exception:
                            price = 0
                        url = info.get('productUrl') or info.get('url') or info.get('productUrlV1')
                        brand = info.get('productBrand') or info.get('brand') or info.get('manufacturer')
                        # images may be in imageUrls or imageUrls['200x200']
                        if info.get('imageUrls'):
                            if isinstance(info['imageUrls'], dict):
                                image = next(iter(info['imageUrls'].values()), None)
                            elif isinstance(info['imageUrls'], list):
                                image = info['imageUrls'][0]
                        image = image or info.get('image') or info.get('imageUrl')

                    items.append({
                        'title': title,
                        'price': price,
                        'url': url,
                        'platform': 'Flipkart',
                        'brand': brand,
                        'image': image,
                        'source': 'flipkart_api'
                    })
                except Exception:
                    continue

            # If affiliate API didn't return useful items, fallback to scraper
            if not items and PriceComparisonScraper is not None:
                scraper = PriceComparisonScraper()
                return scraper.flipkart_scraper.search_product(query, max_results=max_results)

            return items
        except Exception:
            if PriceComparisonScraper is not None:
                scraper = PriceComparisonScraper()
                return scraper.flipkart_scraper.search_product(query, max_results)
            raise

    if PriceComparisonScraper is None:
        return []
    scraper = PriceComparisonScraper()
    return scraper.flipkart_scraper.search_product(query, max_results=max_results)


__all__ = ['search_amazon', 'search_flipkart', 'has_amazon_keys', 'has_flipkart_keys']
