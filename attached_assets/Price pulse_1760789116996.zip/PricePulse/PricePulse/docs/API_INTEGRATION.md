# API Integration Guide for PricePulse

This document explains how to integrate official product APIs for Amazon and Flipkart, what credentials are required, and important legal/operational notes.

## Overview
Where possible you should use official product APIs or affiliate APIs to fetch product metadata and prices. Scraping site HTML is fragile and may violate terms of service.

Supported official options:
- Amazon Product Advertising API (PA-API)
- Flipkart Affiliate API (requires an affiliate account and API access)

## Environment variables
Add the following to your `.env` (or environment) when you obtain keys:

- AMAZON_ACCESS_KEY
- AMAZON_SECRET_KEY
- AMAZON_ASSOCIATE_TAG
- FLIPKART_AFFILIATE_ID
- FLIPKART_AFFILIATE_TOKEN

The code expects these to be present to enable the API adapters.

## Amazon Product Advertising API
- Sign up for an Amazon Associates account and create credentials for PA-API.
- You will need Access Key, Secret Key and Associate Tag.
- Limitations: PA-API has request quotas per account and region; you'll need to cache responses and respect rate limits.
- SDKs: Amazon provides SDKs and canonical examples for signing requests. Prefer using the official SDKs.

## Flipkart Affiliate API
- Create a Flipkart affiliate account and generate API token/ID.
- The API returns product lists and price details for affiliate usage.

## Legal and rate-limit notes
- Respect each API's rate limits and cache responses.
- Avoid scraping as the primary data-source for production; use official APIs where possible.
- If you do scrape, use rotating proxies and throttling and be prepared to handle blocks.

## How the project will use APIs
- We'll implement adapters that prefer official APIs when environment variables/keys are present.
- If no keys are present, the code can fall back to the existing scraper but will use the `services/http_client.HttpClient` for throttling, headers and optional proxy rotation.

## Next steps
- Add API adapter implementations (this repo includes a scaffold file) and wire them into the seeder so that if keys are present, data comes from APIs.
- Add a small caching layer (Redis or file cache) to reduce API calls and respect rate limits.

If you want, I can implement the Amazon PA-API adapter next (I'll need your keys to test live requests), or I can implement the adapter scaffold and mock tests so you can plug in keys later.