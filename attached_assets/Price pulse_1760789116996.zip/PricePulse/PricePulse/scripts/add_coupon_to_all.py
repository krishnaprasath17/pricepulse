"""Add or update coupon for all products in the database.
Usage:
    python add_coupon_to_all.py --code SAVE10 --type percent --amount 10 --platform Both --expires 2025-12-31

This script requires the app's Flask context to access the SQLAlchemy `db` and `Product`.
"""
import argparse
from datetime import datetime
import os

from models import db, Product
from flask import Flask
import os


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument('--code', required=True, help='Coupon code to apply')
    p.add_argument('--type', choices=['percent', 'fixed'], default='percent')
    p.add_argument('--amount', type=float, required=True)
    p.add_argument('--platform', choices=['Amazon', 'Flipkart', 'Both'], default='Both')
    p.add_argument('--expires', help='Expiry date YYYY-MM-DD (optional)')
    return p.parse_args()


def main():
    args = parse_args()
    expires = None
    if args.expires:
        expires = datetime.strptime(args.expires, '%Y-%m-%d')

    # Create a minimal Flask app configured to use the project's instance SQLite DB
    app = Flask(__name__)
    sqlite_path = os.path.join(os.getcwd(), 'instance', 'pricepulse.db')
    app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{sqlite_path}'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    db.init_app(app)

    def ensure_coupon_columns(conn):
        """Ensure required coupon columns exist in the products table (SQLite)."""
        col_defs = [
            ("coupon_code", "TEXT"),
            ("coupon_type", "TEXT"),
            ("coupon_amount", "REAL"),
            ("coupon_platform", "TEXT"),
            ("coupon_expires", "TEXT")
        ]
        cur = conn.cursor()
        # get existing columns
        cur.execute("PRAGMA table_info(products)")
        existing = {row[1] for row in cur.fetchall()}  # name is at index 1
        for name, sqltype in col_defs:
            if name not in existing:
                try:
                    cur.execute(f"ALTER TABLE products ADD COLUMN {name} {sqltype}")
                    print(f'Added column {name}')
                except Exception as e:
                    print(f'Failed to add column {name}:', e)
        conn.commit()

    with app.app_context():
        # Ensure schema has coupon columns in case migrations haven't run
        engine = db.get_engine()
        with engine.connect() as conn:
            # For SQLite, we can use raw connection
            try:
                raw_conn = conn.connection
            except Exception:
                raw_conn = conn
            ensure_coupon_columns(raw_conn)

        products = Product.query.all()
        print(f'Found {len(products)} products. Applying coupon {args.code}...')
        for p in products:
            p.coupon_code = args.code
            p.coupon_type = args.type
            p.coupon_amount = args.amount
            p.coupon_platform = args.platform
            p.coupon_expires = expires
            db.session.add(p)
        db.session.commit()
        print('Done.')


if __name__ == '__main__':
    main()
