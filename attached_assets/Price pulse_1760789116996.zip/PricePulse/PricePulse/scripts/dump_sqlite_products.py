import os
import sqlite3

def inspect_db(path):
    print('\nDB:', path)
    if not os.path.exists(path):
        print('  (not found)')
        return
    st = os.stat(path)
    print(f'  Size: {st.st_size} bytes')
    try:
        conn = sqlite3.connect(path)
        cur = conn.cursor()
        # check if products table exists
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='products'")
        if not cur.fetchone():
            print('  No `products` table found in this DB')
            return
        cur.execute('SELECT COUNT(*) FROM products')
        count = cur.fetchone()[0]
        print(f'  product rows: {count}')
        cur.execute('SELECT id, category, product_name, brand, amazon_price, flipkart_price FROM products ORDER BY id LIMIT 5')
        rows = cur.fetchall()
        if rows:
            print('  Sample rows (up to 5):')
            for r in rows:
                print('   ', r)
        else:
            print('  products table is empty')
    except Exception as e:
        print('  Error inspecting DB:', e)
    finally:
        try:
            conn.close()
        except:
            pass

if __name__ == '__main__':
    paths = [
        r'D:\PricePulse\instance\pricepulse.db',
        r'D:\PricePulse\PricePulse\instance\pricepulse.db',
        r'D:\PricePulse\PricePulse\pricepulse.db',
    ]
    for p in paths:
        inspect_db(p)
    print('\nDone')
