import sys, os
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from models import db, Product, PriceHistory
from flask import Flask

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///pricepulse.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

with app.app_context():
    prod_count = Product.query.count()
    ph_count = PriceHistory.query.count()
    print(f'Products: {prod_count}, PriceHistory entries: {ph_count}')
    rows = PriceHistory.query.order_by(PriceHistory.recorded_at.desc()).limit(5).all()
    print('\nRecent PriceHistory:')
    for r in rows:
        print(r.id, 'pid=', r.product_id, 'am=', r.amazon_price, 'fk=', r.flipkart_price, 'at=', r.recorded_at, 'src=', r.source)
