import sqlite3
import os

db_path = os.path.join(os.getcwd(), 'instance', 'pricepulse.db')
print('DB:', db_path)
if not os.path.exists(db_path):
    print('DB file not found')
    raise SystemExit(1)

conn = sqlite3.connect(db_path)
cur = conn.cursor()
try:
    cur.execute("SELECT id, product_name, coupon_code, coupon_type, coupon_amount, coupon_platform, coupon_expires FROM products ORDER BY id LIMIT 10")
    rows = cur.fetchall()
    print(f'Found {len(rows)} rows (sample up to 10):')
    for r in rows:
        print(r)
except Exception as e:
    print('Error querying DB:', e)
finally:
    conn.close()
