import os
import sys

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from flask import Flask
from models import db, Product


def clear_brands(db_path='instance/pricepulse.db'):
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{db_path}'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    db.init_app(app)

    changed = 0
    with app.app_context():
        products = Product.query.all()
        for p in products:
            if p.brand:
                p.brand = None
                db.session.add(p)
                changed += 1
        if changed:
            db.session.commit()

    return changed


if __name__ == '__main__':
    n = clear_brands()
    print('Cleared brand for', n, 'products')
