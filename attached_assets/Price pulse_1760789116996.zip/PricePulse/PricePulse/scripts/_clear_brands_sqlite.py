import sqlite3
con = sqlite3.connect('instance/pricepulse.db')
cur = con.cursor()
cur.execute('UPDATE products SET brand = NULL WHERE brand IS NOT NULL')
changed = cur.rowcount
con.commit()
con.close()
print('Cleared brand for', changed, 'products')
