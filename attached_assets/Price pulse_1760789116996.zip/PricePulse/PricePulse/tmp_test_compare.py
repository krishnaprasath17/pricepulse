# Quick test for /api/compare endpoint
from run_app import app, db, Product
import json

with app.test_client() as c:
    # Ensure seeded data exists
    with app.app_context():
        products = Product.query.limit(4).all()
        ids = [p.id for p in products]
        print('Using product ids for test:', ids)

    if len(ids) < 2:
        print('Need at least 2 products in DB to run the compare test')
    else:
        payload = {'productIds': ids[:3]}  # test with 3 products
        rv = c.post('/api/compare', json=payload)
        print('Status:', rv.status_code)
        try:
            print(json.dumps(rv.get_json(), indent=2))
        except Exception:
            print('Response (raw):', rv.data)
