# Install Python for PricePulse

## Quick Installation Steps

### Step 1: Download Python
1. Go to: https://www.python.org/downloads/
2. Click "Download Python 3.11.x" (latest version)
3. The download will start automatically

### Step 2: Install Python
1. **Run the installer** as Administrator
2. **IMPORTANT**: Check "Add Python to PATH" at the bottom of the installer
3. Click "Install Now"
4. Wait for installation to complete

### Step 3: Verify Installation
1. Close and reopen your terminal/PowerShell
2. Type: `python --version`
3. You should see: `Python 3.11.x`

### Step 4: Run PricePulse
Once Python is installed, come back here and run:
```bash
python run_app.py
```

## Alternative: Use Microsoft Store
1. Open Microsoft Store
2. Search for "Python 3.11"
3. Click "Install"
4. This automatically adds Python to PATH

## If You Get Permission Errors
1. Right-click on PowerShell/Command Prompt
2. Select "Run as Administrator"
3. Try the installation again

## After Installation
Once Python is installed, the PricePulse Flask application will:
- ✅ Install required packages automatically
- ✅ Create SQLite database with sample data
- ✅ Start web server on http://localhost:5000
- ✅ Show all product comparison features

## Troubleshooting
- **"python not found"**: Restart your terminal after installation
- **Permission denied**: Run terminal as Administrator
- **Installation fails**: Try Microsoft Store version instead

## What You'll Get
- Full Flask backend with database
- Web scraping capabilities
- Product comparison features
- Price tracking functionality
- Modern responsive web interface

Install Python and then run: `python run_app.py`
