#!/usr/bin/env python3
"""
Scrape Amazon and Flipkart for sample products and add them to the local SQLite DB.

This script uses the existing scraper.py module to fetch search results and then
creates Product entries in the local SQLAlchemy database (`pricepulse.db`). It
combines the top Amazon and top Flipkart result for a query into a single product
record (so both amazon/flipkart prices/urls are present).

Run:
  D:/PricePulse/PricePulse/.venv/Scripts/python.exe scrape_and_add_products.py

Note: the scrapers may be subject to site blocking. The script sleeps between
requests and tolerates failures, and will skip duplicates.
"""

import time
import sys
import os
from urllib.parse import urlparse

# Ensure project root on path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from scraper import PriceComparisonScraper
from models import db, Product
from flask import Flask
from difflib import SequenceMatcher


def create_app_for_db():
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'scrape-seed-key'
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///pricepulse.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    db.init_app(app)
    return app


def extract_brand_from_title(title: str) -> str:
    if not title:
        return 'Unknown'
    # Common brand is usually the first token
    brand = title.split()[0]
    # cleanup if contains punctuation
    return brand.strip(' ,.-()')


def similar(a: str, b: str) -> float:
    if not a or not b:
        return 0.0
    return SequenceMatcher(None, a.lower(), b.lower()).ratio()


def unify_and_add(amazon_item, flipkart_item, category):
    """Insert or update a product. Returns 'inserted', 'updated', or False if skipped."""
    # Choose primary name
    name = (amazon_item.get('title') if amazon_item else None) or (flipkart_item.get('title') if flipkart_item else None)
    if not name:
        return False

    amazon_price = amazon_item.get('price') if amazon_item and amazon_item.get('price') is not None else None
    flipkart_price = flipkart_item.get('price') if flipkart_item and flipkart_item.get('price') is not None else None

    # Ensure numeric fallback
    if amazon_price is None and flipkart_price is None:
        return False
    if amazon_price is None:
        amazon_price = flipkart_price
    if flipkart_price is None:
        flipkart_price = amazon_price

    amazon_url = amazon_item.get('url') if amazon_item else ''
    flipkart_url = flipkart_item.get('url') if flipkart_item else ''

    brand = extract_brand_from_title(name)

    # Try find existing product by URL first (strong check)
    exists = None
    if amazon_url:
        exists = db.session.query(Product).filter(Product.amazon_url == amazon_url).first()
    if not exists and flipkart_url:
        exists = db.session.query(Product).filter(Product.flipkart_url == flipkart_url).first()

    # Next try fuzzy name match (threshold 0.85)
    if not exists:
        candidates = db.session.query(Product).all()
        for c in candidates:
            if similar(c.product_name or '', name) > 0.85:
                exists = c
                break

    if exists:
        # Update existing record if prices or urls changed
        changed = False
        if amazon_url and exists.amazon_url != amazon_url:
            exists.amazon_url = amazon_url
            changed = True
        if flipkart_url and exists.flipkart_url != flipkart_url:
            exists.flipkart_url = flipkart_url
            changed = True
        if amazon_price and exists.amazon_price != float(amazon_price):
            exists.amazon_price = float(amazon_price)
            changed = True
        if flipkart_price and exists.flipkart_price != float(flipkart_price):
            exists.flipkart_price = float(flipkart_price)
            changed = True

        if changed:
            db.session.add(exists)
            db.session.commit()
            return 'updated'
        return False

    # Insert new product
    product = Product(
        category=category,
        product_name=name,
        brand=brand,
        amazon_price=float(amazon_price),
        amazon_url=amazon_url or '',
        flipkart_price=float(flipkart_price),
        flipkart_url=flipkart_url or ''
    )

    db.session.add(product)
    db.session.commit()
    return 'inserted'


def main():
    scraper = PriceComparisonScraper()
    app = create_app_for_db()

    # Queries grouped by category
    queries = {
        'Phones': ['iPhone 15', 'Samsung Galaxy', 'OnePlus Nord', 'Redmi Note 14', 'POCO F7'],
        'Laptops': ['MacBook Air', 'Dell Inspiron', 'HP Pavilion', 'Lenovo ThinkBook', 'ASUS Vivobook'],
        'Headphones': ['boAt Airdopes', 'Sony WH-1000XM5', 'JBL Tune 510', 'Anker Soundcore', 'Noise earbuds']
    }

    inserted = 0
    attempted = 0

    with app.app_context():
        for category, qs in queries.items():
                for q in qs:
                    try:
                        attempted += 1
                        print(f"Searching '{q}' on both platforms...")
                        results = scraper.search_products(q, max_results_per_platform=5)

                        amazon_list = results.get('amazon', [])
                        flipkart_list = results.get('flipkart', [])

                        maxlen = max(len(amazon_list), len(flipkart_list), 1)
                        added_any = False

                        # Try pairing multiple top results
                        for i in range(maxlen):
                            amazon_item = amazon_list[i] if i < len(amazon_list) else None
                            flipkart_item = flipkart_list[i] if i < len(flipkart_list) else None

                            res = unify_and_add(amazon_item, flipkart_item, category)
                            if res == 'inserted':
                                inserted += 1
                                added_any = True
                                print(f"  + Inserted: {amazon_item.get('title') if amazon_item else flipkart_item.get('title')}")
                            elif res == 'updated':
                                print("  * Updated existing product")
                            else:
                                # skip or no-op
                                pass

                            # polite micro-delay
                            time.sleep(1)

                        if not added_any:
                            print("  - No new products added for this query (likely duplicates)")

                    except Exception as e:
                        print(f"Error while processing query '{q}': {e}")
                        time.sleep(2)
                        continue

    print(f"\nDone. Attempted: {attempted}, Inserted: {inserted}")


if __name__ == '__main__':
    main()
